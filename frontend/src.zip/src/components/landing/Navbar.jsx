import { Link, useNavigate } from "react-router-dom";
import { FaSignOutAlt } from "react-icons/fa";
import "./Navbar.css";

// Landing page navbar. Swaps Login/Register links for a
// Dashboard link + Logout button based on presence of a stored token.
// NOTE: this is the Navbar actually used by the app; a second, unused
// `components/common/Navbar.jsx` also exists — see notes below.

function Navbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <nav className="landing-navbar">
      <div className="landing-nav-inner">
        <Link to="/" className="logo-link">
          <span className="logo-icon">₹</span>
          <span>ExpenseTracker</span>
        </Link>

        <div className="nav-links">
          <ul>
            <li>
              <a href="#features">Features</a>
            </li>

            <li>
              <a href="#tech-stack">Tech Stack</a>
            </li>

            {token ? (
              <>
                <li>
                  <Link to="/dashboard">Dashboard</Link>
                </li>

                <li>
                  <button onClick={handleLogout} className="btn-logout">
                    <FaSignOutAlt />
                    <span>Logout</span>
                  </button>
                </li>
              </>
            ) : (
              <>
                <li>
                  <Link to="/login" className="btn-secondary">
                    Login
                  </Link>
                </li>

                <li>
                  <Link to="/register" className="btn-primary">
                    Get Started
                  </Link>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
